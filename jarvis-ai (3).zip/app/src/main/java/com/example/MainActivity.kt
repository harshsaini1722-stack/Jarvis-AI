package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppDatabase
import com.example.data.repository.WorkflowRepository
import com.example.ui.theme.*
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.RoutinesScreen
import com.example.ui.screens.TerminalScreen
import com.example.viewmodel.JarvisViewModel
import com.example.viewmodel.JarvisViewModelFactory

enum class Screen {
    TERMINAL, ROUTINES, DIAGNOSTICS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize local SQLite Room Database
        val database = AppDatabase.getDatabase(applicationContext)
        val workflowDao = database.workflowDao()

        // 2. Wrap into Workflow Repository layer
        val repository = WorkflowRepository(workflowDao)

        // 3. Create ViewModel Factory and obtain JarvisViewModel
        val viewModelFactory = JarvisViewModelFactory(repository)
        val viewModel = ViewModelProvider(this, viewModelFactory)[JarvisViewModel::class.java]

        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf(Screen.TERMINAL) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // High-tech holographic Bottom Navigation Bar
                        Column {
                            HorizontalDivider(color = CyberCyan.copy(alpha = 0.15f), thickness = 1.dp)
                            NavigationBar(
                                modifier = Modifier.testTag("bottom_nav_bar"),
                            containerColor = ObsidianDark,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentScreen == Screen.TERMINAL,
                                onClick = { currentScreen = Screen.TERMINAL },
                                modifier = Modifier.testTag("nav_tab_terminal"),
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Core Terminal"
                                    )
                                },
                                label = {
                                    Text(
                                        "CORE",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianDark,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberCyan,
                                    unselectedIconColor = SilverShieldText,
                                    unselectedTextColor = SilverShieldText
                                )
                            )

                            NavigationBarItem(
                                selected = currentScreen == Screen.ROUTINES,
                                onClick = { currentScreen = Screen.ROUTINES },
                                modifier = Modifier.testTag("nav_tab_routines"),
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Build,
                                        contentDescription = "Workflow Matrix"
                                    )
                                },
                                label = {
                                    Text(
                                        "MATRIX",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianDark,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberCyan,
                                    unselectedIconColor = SilverShieldText,
                                    unselectedTextColor = SilverShieldText
                                )
                            )

                            NavigationBarItem(
                                selected = currentScreen == Screen.DIAGNOSTICS,
                                onClick = { currentScreen = Screen.DIAGNOSTICS },
                                modifier = Modifier.testTag("nav_tab_diagnostics"),
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.List,
                                        contentDescription = "System Diagnostics"
                                    )
                                },
                                label = {
                                    Text(
                                        "LOGS",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianDark,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberCyan,
                                    unselectedIconColor = SilverShieldText,
                                    unselectedTextColor = SilverShieldText
                                )
                            )
                        }
                    }
                }
                ) { innerPadding ->
                    // Main Container under the new unified J.A.R.V.I.S. Core Premium Header
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ObsidianDark)
                            .padding(
                                start = innerPadding.calculateStartPadding(androidx.compose.ui.unit.LayoutDirection.Ltr),
                                top = 0.dp,
                                end = innerPadding.calculateEndPadding(androidx.compose.ui.unit.LayoutDirection.Ltr),
                                bottom = innerPadding.calculateBottomPadding()
                            )
                            .statusBarsPadding()
                    ) {
                        // Cohesive Premium J.A.R.V.I.S. Header from Design Theme
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 24.dp, top = 20.dp, end = 24.dp, bottom = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Rounded Soft Amethyst Pulse Icon Circle
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(CyberCyan, shape = CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Power Bolt Status",
                                        tint = ElectricBlue,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        "J.A.R.V.I.S.",
                                        color = OffwhiteJet,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        "System Optimized",
                                        color = SilverShieldText,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            // Dynamic styled settings/status button
                            IconButton(
                                onClick = { /* Settings action */ },
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(CyberPanel, shape = CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Settings Option",
                                    tint = OffwhiteJet,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        HorizontalDivider(
                            color = CyberCyan.copy(alpha = 0.12f),
                            thickness = 1.dp,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        // Main screen content fits into weight container
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            when (currentScreen) {
                                Screen.TERMINAL -> {
                                    TerminalScreen(
                                        viewModel = viewModel,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Screen.ROUTINES -> {
                                    RoutinesScreen(
                                        viewModel = viewModel,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Screen.DIAGNOSTICS -> {
                                    DiagnosticsScreen(
                                        viewModel = viewModel,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
