package com.example.data.local

import androidx.room.*
import com.example.data.model.WorkflowBlueprint
import com.example.data.model.WorkflowHistoryLog
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkflowDao {
    @Query("SELECT * FROM workflows ORDER BY title ASC")
    fun getAllBlueprints(): Flow<List<WorkflowBlueprint>>

    @Query("SELECT * FROM workflows WHERE id = :id")
    suspend fun getBlueprintById(id: Int): WorkflowBlueprint?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlueprint(blueprint: WorkflowBlueprint): Long

    @Update
    suspend fun updateBlueprint(blueprint: WorkflowBlueprint)

    @Delete
    suspend fun deleteBlueprint(blueprint: WorkflowBlueprint)

    @Query("UPDATE workflows SET executionCount = executionCount + 1, lastExecuted = :timestamp WHERE id = :id")
    suspend fun incrementExecutionStats(id: Int, timestamp: Long)

    @Query("SELECT * FROM workflow_logs ORDER BY timestamp DESC LIMIT 200")
    fun getAllLogs(): Flow<List<WorkflowHistoryLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: WorkflowHistoryLog)

    @Query("DELETE FROM workflow_logs")
    suspend fun clearLogs()
}
