package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workflows")
data class WorkflowBlueprint(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val triggerCondition: String,
    val actionsJson: String, // Comma-separated or JSON list of action steps
    val isActive: Boolean = true,
    val iconName: String = "AutoRenew",
    val executionCount: Int = 0,
    val lastExecuted: Long = 0L
)

@Entity(tableName = "workflow_logs")
data class WorkflowHistoryLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val workflowId: Int?,
    val workflowName: String,
    val logMessage: String,
    val status: String, // SUCCESS, INFO, ERROR, WARNING
    val generatedResponse: String? = null
)
