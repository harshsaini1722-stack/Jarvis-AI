package com.example.data.repository

import com.example.BuildConfig
import com.example.data.api.Content
import com.example.data.api.GenerateContentRequest
import com.example.data.api.Part
import com.example.data.api.RetrofitClient
import com.example.data.local.WorkflowDao
import com.example.data.model.WorkflowBlueprint
import com.example.data.model.WorkflowHistoryLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class WorkflowRepository(private val dao: WorkflowDao) {

    val allBlueprints: Flow<List<WorkflowBlueprint>> = dao.getAllBlueprints()
    val allLogs: Flow<List<WorkflowHistoryLog>> = dao.getAllLogs()

    suspend fun getBlueprintById(id: Int): WorkflowBlueprint? = withContext(Dispatchers.IO) {
        dao.getBlueprintById(id)
    }

    suspend fun insertBlueprint(blueprint: WorkflowBlueprint): Long = withContext(Dispatchers.IO) {
        dao.insertBlueprint(blueprint)
    }

    suspend fun updateBlueprint(blueprint: WorkflowBlueprint) = withContext(Dispatchers.IO) {
        dao.updateBlueprint(blueprint)
    }

    suspend fun deleteBlueprint(blueprint: WorkflowBlueprint) = withContext(Dispatchers.IO) {
        dao.deleteBlueprint(blueprint)
    }

    suspend fun insertLog(log: WorkflowHistoryLog) = withContext(Dispatchers.IO) {
        dao.insertLog(log)
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        dao.clearLogs()
    }

    suspend fun incrementExecutionStats(id: Int, timestamp: Long) = withContext(Dispatchers.IO) {
        dao.incrementExecutionStats(id, timestamp)
    }

    /**
     * Sends a request to the Gemini API to get a response.
     * Uses BuildConfig.GEMINI_API_KEY.
     * Fallbacks to pre-programmed smart voice sequences if API key is not configured or requests fail.
     */
    suspend fun generateJarvisResponse(prompt: String, systemInstruction: String? = null): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getOfflineJarvisResponse(prompt)
        }

        try {
            val systemContent = systemInstruction?.let {
                Content(parts = listOf(Part(text = it)))
            }
            val request = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                systemInstruction = systemContent
            )
            val response = RetrofitClient.service.generateContent(apiKey, request)
            val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!responseText.isNullOrBlank()) {
                responseText
            } else {
                "Incoming telemetry confirms an empty transmission from central command core, Sir. Running diagnostics."
            }
        } catch (e: Exception) {
            "Core network exception encountered, Sir: ${e.localizedMessage}. Initiating secondary local simulation matrix buffers."
        }
    }

    private fun getOfflineJarvisResponse(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("hello") || lower.contains("hi jarvis") || lower.contains("wake up") -> {
                "Welcome back, Sir. Core functions are active, though terminal uplink key is not fully configured. Local simulation is online at 100% efficiency. Ready for your instructions."
            }
            lower.contains("routine") || lower.contains("workflow") || lower.contains("automate") -> {
                "Understood, Sir. I have calibrated standard local protocols: Sunrise morning briefing, deep focus blocks, and reflective diagnostic logs. Select 'Workflows' panel to trigger manual micro-executions."
            }
            lower.contains("weather") -> {
                "Local atmospheric moisture is within optimal bounds. Current prediction engine is simulated, estimating a comfortable 72°F with virtual blue skies, Sir."
            }
            lower.contains("schedule") || lower.contains("today") || lower.contains("calendar") -> {
                "Your schedule is presently integrated via local cache. You have configured 4 automated workflow triggers for high-frequency daily synchronization."
            }
            lower.contains("status") || lower.contains("system") || lower.contains("diagnostics") -> {
                "System telemetry: Room database active, Retrofit buffers set, local matrix intact. Terminal key missing standard Gemini cloud registry, but fallback engine is performing flawlessly, Sir."
            }
            else -> {
                "Acknowledged, Sir. Query received: '$prompt'. Fallback generator logs a 100% success rate. If you would like to enable direct neural Gemini API calls, please enter your personal API key in AI Studio's Secrets panel."
            }
        }
    }
}
