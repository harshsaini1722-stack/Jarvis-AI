package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark M3 Purple & Lavender Palette
val CyberCyan = Color(0xFFD0BCFE)         // Soft Highlight Lavender
val ElectricBlue = Color(0xFF4F378B)      // Deep Accent Purple
val CyberAmber = Color(0xFFEADDFF)        // Light Amethyst Tint
val CyberBrightGreen = Color(0xFFD0BCFE)  // Lavender Core Glow
val CyberCrimson = Color(0xFFF2B8B5)      // Elegant Red M3

val ObsidianDark = Color(0xFF1C1B1F)      // Elegant Dark Pitch Web Background
val CyberSurface = Color(0xFF2B2930)      // Cozy Dark Purple Slate Surface
val CyberPanel = Color(0xFF332D41)        // Subdued Indigo Deep Panel

val LiquidBlueText = Color(0xFFE6E1E5)    // Pale Lavender Offwhite
val SilverShieldText = Color(0xFF938F99)  // Medium Ash Slate Purple
val OffwhiteJet = Color(0xFFF4EFF4)       // Primary Light High-Contrast Text

