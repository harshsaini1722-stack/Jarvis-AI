package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.WorkflowBlueprint
import com.example.ui.theme.*
import com.example.viewmodel.JarvisViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RoutinesScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val workflows by viewModel.workflows.collectAsState()
    val activeExecution by viewModel.activeExecution.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "AUTOMATION MATRIX",
                        color = CyberCyan,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Compile daily workflow triggers & instructions",
                        color = SilverShieldText,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("compile_protocol_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add New",
                        tint = ObsidianDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "COMPILE",
                        color = ObsidianDark,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Routine Lists
            if (workflows.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "SYSTEM COLD: No automation blocks compiled. Launching seed algorithms.",
                        color = CyberAmber,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(32.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(workflows, key = { it.id }) { blueprint ->
                        WorkflowBlueprintCard(
                            blueprint = blueprint,
                            onExecute = { viewModel.executeWorkflow(blueprint) },
                            onToggle = { viewModel.toggleWorkflowActive(blueprint) },
                            onDelete = { viewModel.deleteWorkflow(blueprint) },
                            isExecutingThis = activeExecution?.blueprintId == blueprint.id
                        )
                    }
                }
            }
        }

        // Active Telemetry Execution Overlay System
        AnimatedVisibility(
            visible = activeExecution != null,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(500)),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            activeExecution?.let { execution ->
                TelemetryExecutionOverlay(execution = execution)
            }
        }

        // Dialog for Custom Protocol Compilation
        if (showCreateDialog) {
            CompileProtocolDialog(
                onDismiss = { showCreateDialog = false },
                onCompile = { title, desc, trigger, actions ->
                    viewModel.addNewWorkflow(title, desc, trigger, actions)
                    showCreateDialog = false
                }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkflowBlueprintCard(
    blueprint: WorkflowBlueprint,
    onExecute: () -> Unit,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    isExecutingThis: Boolean
) {
    val steps = remember(blueprint.actionsJson) {
        blueprint.actionsJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isExecutingThis) CyberCyan else CyberCyan.copy(alpha = 0.15f),
                RoundedCornerShape(12.dp)
            )
            .clip(RoundedCornerShape(12.dp))
            .background(CyberSurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // System Preset Visual Icon Shape
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (isExecutingThis) ElectricBlue.copy(alpha = 0.3f) else CyberCyan.copy(alpha = 0.08f),
                                RoundedCornerShape(8.dp)
                            )
                            .border(
                                1.dp,
                                if (isExecutingThis) CyberCyan else CyberCyan.copy(alpha = 0.2f),
                                RoundedCornerShape(8.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        val icon = when (blueprint.iconName) {
                            "WbSunny" -> Icons.Default.Star
                            "Computer" -> Icons.Default.Build
                            "Psychology" -> Icons.Default.Info
                            "Fitness" -> Icons.Default.PlayArrow
                            else -> Icons.Default.Refresh
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = blueprint.iconName,
                            tint = if (isExecutingThis) CyberCyan else CyberCyan.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = blueprint.title,
                            color = if (isExecutingThis) CyberCyan else OffwhiteJet,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Trigger Schedule",
                                tint = CyberAmber,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = blueprint.triggerCondition,
                                color = CyberAmber,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Delete option
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = CyberCrimson.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Description
            Text(
                text = blueprint.description,
                color = SilverShieldText,
                fontSize = 11.5.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 15.sp,
                modifier = Modifier.padding(horizontal = 2.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Command step action tags
            Text(
                "AUTOMATED PROTOCOL SEQUENCES:",
                color = CyberCyan.copy(alpha = 0.5f),
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                steps.forEachIndexed { i, step ->
                    Box(
                        modifier = Modifier
                            .background(CyberPanel.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .border(0.5.dp, CyberCyan.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "[${i + 1}] $step",
                            color = LiquidBlueText,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action triggers
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Activation Switch
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = blueprint.isActive,
                        onCheckedChange = { onToggle() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberBrightGreen,
                            checkedTrackColor = CyberBrightGreen.copy(alpha = 0.3f),
                            uncheckedThumbColor = SilverShieldText,
                            uncheckedTrackColor = CyberSurface
                        ),
                        modifier = Modifier.scale(0.8f).testTag("blueprint_toggle")
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (blueprint.isActive) "SYSTEM ACTIVE" else "DEACTIVATED",
                        color = if (blueprint.isActive) CyberBrightGreen else SilverShieldText,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Run execution
                Button(
                    onClick = onExecute,
                    enabled = blueprint.isActive && !isExecutingThis,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricBlue,
                        disabledContainerColor = CyberPanel
                    ),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("run_workflow_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Run Protocol",
                        tint = if (blueprint.isActive && !isExecutingThis) Color.White else SilverShieldText.copy(alpha = 0.3f),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "ENGAGE PROTOCOL",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (blueprint.isActive && !isExecutingThis) Color.White else SilverShieldText.copy(alpha = 0.3f)
                    )
                }
            }
        }
    }
}

@Composable
fun TelemetryExecutionOverlay(execution: com.example.viewmodel.ExecutionState) {
    val progress = execution.currentStepIndex.toFloat() / execution.totalSteps.toFloat()
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(600, easing = LinearOutSlowInEasing),
        label = "progressBar"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color.Transparent, ObsidianDark.copy(alpha = 0.95f))
                )
            )
            .padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberCyan, RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(CyberSurface)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Title Block
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = CyberCyan,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ACTIVE PROTOCOL: ${execution.title}",
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "${execution.currentStepIndex}/${execution.totalSteps} SECONDS",
                        color = CyberAmber,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Detail Action Label
                Text(
                    text = execution.currentStepLabel,
                    color = OffwhiteJet,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(start = 24.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Tech Progress bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .background(CyberPanel, RoundedCornerShape(4.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(animatedProgress)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(ElectricBlue, CyberCyan)
                                ),
                                RoundedCornerShape(4.dp)
                            )
                    )
                }
            }
        }
    }
}

// Dialog to Compile customized protocols
@Composable
fun CompileProtocolDialog(
    onDismiss: () -> Unit,
    onCompile: (String, String, String, List<String>) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var scheduling by remember { mutableStateOf("") }
    var stepsString by remember { mutableStateOf("") }

    val stepsList = remember(stepsString) {
        stepsString.split(",").map { it.trim() }.filter { it.isNotBlank() }
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberCyan, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(ObsidianDark)
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "COMPILE AUTONOMOUS RULE",
                    color = CyberCyan,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                CardTextField(
                    label = "Routine Title",
                    value = title,
                    onValueChange = { title = it },
                    placeholder = "e.g., Evening Reflection Matrix",
                    testTag = "input_title"
                )

                CardTextField(
                    label = "Core Objective Description",
                    value = description,
                    onValueChange = { description = it },
                    placeholder = "e.g., Re-calibrates active learning filters",
                    testTag = "input_desc"
                )

                CardTextField(
                    label = "Pulse Trigger / Schedule Interval",
                    value = scheduling,
                    onValueChange = { scheduling = it },
                    placeholder = "e.g., Daily at 21:30 or Manual Trigger",
                    testTag = "input_trigger"
                )

                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Micro-Action Steps (comma-separated)",
                        color = SilverShieldText,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    OutlinedTextField(
                        value = stepsString,
                        onValueChange = { stepsString = it },
                        modifier = Modifier.fillMaxWidth().testTag("input_actions"),
                        placeholder = {
                            Text(
                                "e.g., Warm coffee pot, Poll atmospheric index, Run brief",
                                color = SilverShieldText.copy(alpha = 0.5f),
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(
                            color = LiquidBlueText,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberCyan.copy(alpha = 0.3f),
                            focusedContainerColor = CyberSurface,
                            unfocusedContainerColor = CyberSurface
                        )
                    )
                }

                // Show step previews
                if (stepsList.isNotEmpty()) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "SEQUENCE PATH PREVIEW:",
                            color = CyberCyan.copy(alpha = 0.6f),
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Column(
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            stepsList.take(3).forEachIndexed { index, step ->
                                Text(
                                    "[Step ${index + 1}] $step",
                                    color = LiquidBlueText,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            if (stepsList.size > 3) {
                                Text(
                                    "...and ${stepsList.size - 3} more actions",
                                    color = SilverShieldText,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SilverShieldText),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SilverShieldText.copy(alpha = 0.4f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ABORT", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank() && stepsList.isNotEmpty()) {
                                onCompile(title, description, scheduling, stepsList)
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                        modifier = Modifier.weight(1f).testTag("compile_button")
                    ) {
                        Text("COMPILE", color = ObsidianDark, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CardTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    testTag: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            label,
            color = SilverShieldText,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth().testTag(testTag),
            placeholder = {
                Text(
                    placeholder,
                    color = SilverShieldText.copy(alpha = 0.5f),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            },
            singleLine = true,
            textStyle = LocalTextStyle.current.copy(
                color = LiquidBlueText,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyberCyan,
                unfocusedBorderColor = CyberCyan.copy(alpha = 0.3f),
                focusedContainerColor = CyberSurface,
                unfocusedContainerColor = CyberSurface
            )
        )
    }
}


// Inline helper to control graphics layer (if needed) safely
private fun Modifier.customGraphicsLayer(): Modifier = this

