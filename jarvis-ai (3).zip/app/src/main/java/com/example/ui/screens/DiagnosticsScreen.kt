package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WorkflowHistoryLog
import com.example.ui.theme.*
import com.example.viewmodel.JarvisViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DiagnosticsScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val workflows by viewModel.workflows.collectAsState()
    val historyLogs by viewModel.historyLogs.collectAsState()

    val totalExecutions = remember(workflows) {
        workflows.sumOf { it.executionCount }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDark)
            .padding(16.dp)
    ) {
        // Stats Overview Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            DiagnosticStatCard(
                label = "ACTIVE RULES",
                value = workflows.size.toString(),
                subLabel = "Room DB synced",
                color = CyberCyan,
                modifier = Modifier.weight(1f)
            )

            DiagnosticStatCard(
                label = "AUTOMATED RUNS",
                value = totalExecutions.toString(),
                subLabel = "High-frequency logs",
                color = CyberBrightGreen,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            DiagnosticStatCard(
                label = "STARK CELL CORE",
                value = "34.8°C",
                subLabel = "CPU loads nominal",
                color = CyberAmber,
                modifier = Modifier.weight(1f)
            )

            DiagnosticStatCard(
                label = "API COUPLING",
                value = if (com.example.BuildConfig.GEMINI_API_KEY.isNotEmpty() && com.example.BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY") "CONNECTED" else "LOCAL",
                subLabel = "Gemini interface",
                color = if (com.example.BuildConfig.GEMINI_API_KEY.isNotEmpty() && com.example.BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY") CyberBrightGreen else CyberAmber,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Telemetry Wave Line Graph
        Text(
            "LIVE CPU SYNC TELEMETRY",
            color = CyberCyan,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .border(1.dp, CyberCyan.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                .clip(RoundedCornerShape(8.dp))
                .background(CyberSurface.copy(alpha = 0.5f))
        ) {
            LiveTelemetryWaveGraph()
        }

        Spacer(modifier = Modifier.height(16.dp))

        // History Log Header Action Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "SYSTEM CHRONOLOG",
                color = CyberCyan,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            if (historyLogs.isNotEmpty()) {
                TextButton(
                    onClick = { viewModel.clearAllLogs() },
                    colors = ButtonDefaults.textButtonColors(contentColor = CyberCrimson),
                    modifier = Modifier.testTag("clear_logs_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear logs",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "PURGE LOGS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Logs display list
        if (historyLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, CyberCyan.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .background(CyberSurface.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "LOG REGISTERS CLEAR. JARVIS is in stand-by state.",
                    color = SilverShieldText.copy(alpha = 0.7f),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, CyberCyan.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .background(CyberSurface.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                contentPadding = PaddingValues(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(historyLogs) { log ->
                    LogTelemetryItem(log = log)
                }
            }
        }
    }
}

@Composable
fun DiagnosticStatCard(
    label: String,
    value: String,
    subLabel: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .border(1.dp, color.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .background(CyberSurface)
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = label,
                color = SilverShieldText,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                color = color,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(vertical = 2.dp)
            )
            Text(
                text = subLabel,
                color = SilverShieldText.copy(alpha = 0.6f),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun LiveTelemetryWaveGraph() {
    val infiniteTransition = rememberInfiniteTransition(label = "graph")
    val phaseShift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "phase"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Grids
        val horizontalLines = 4
        for (i in 1..horizontalLines) {
            val y = height * (i.toFloat() / (horizontalLines + 1))
            drawLine(
                color = CyberCyan.copy(alpha = 0.05f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f
            )
        }

        val verticalLines = 8
        for (i in 1..verticalLines) {
            val x = width * (i.toFloat() / (verticalLines + 1))
            drawLine(
                color = CyberCyan.copy(alpha = 0.05f),
                start = Offset(x, 0f),
                end = Offset(x, height),
                strokeWidth = 1f
            )
        }

        // Draw animated Sine/Cos telemetry wave
        val wavePath = Path()
        val segments = 100
        val amplitude = height * 0.25f
        val midY = height * 0.5f

        for (i in 0..segments) {
            val x = width * (i.toFloat() / segments)
            // Sine combined harmonic structure for high-tech bio-pulse look
            val angle = (i.toFloat() / segments) * 6f * Math.PI.toFloat() + phaseShift
            val sinVal = Math.sin(angle.toDouble()).toFloat()
            val cosNoise = Math.cos((angle * 2.5f).toDouble()).toFloat() * 0.3f
            val y = midY + (sinVal + cosNoise) * amplitude

            if (i == 0) {
                wavePath.moveTo(x, y)
            } else {
                wavePath.lineTo(x, y)
            }
        }

        // Gradient below curve
        val fillPath = Path().apply {
            addPath(wavePath)
            lineTo(width, height)
            lineTo(0f, height)
            close()
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    ElectricBlue.copy(alpha = 0.15f),
                    Color.Transparent
                )
            )
        )

        drawPath(
            path = wavePath,
            color = CyberCyan,
            style = Stroke(
                width = 3f,
                pathEffect = androidx.compose.ui.graphics.PathEffect.cornerPathEffect(10f)
            )
        )
    }
}

@Composable
fun LogTelemetryItem(log: WorkflowHistoryLog) {
    val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    val dotColor = when (log.status) {
        "SUCCESS" -> CyberBrightGreen
        "WARNING" -> CyberCrimson
        "INFO" -> CyberCyan
        else -> ElectricBlue
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberPanel.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
            .border(0.5.dp, CyberCyan.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Status glowing dot
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(dotColor, RoundedCornerShape(3.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = log.workflowName.uppercase(),
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = formatter.format(Date(log.timestamp)),
                    color = SilverShieldText.copy(alpha = 0.5f),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = log.logMessage,
                color = OffwhiteJet,
                fontSize = 11.5.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 15.sp
            )

            // Dynamic AI response outcomes inside system logs
            if (!log.generatedResponse.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberSurface.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .border(0.5.dp, CyberCyan.copy(alpha = 0.05f), RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Intelligence output",
                                tint = CyberAmber,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "INTELLIGENCE GENERATED RESPONSE:",
                                color = CyberAmber,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = log.generatedResponse,
                            color = LiquidBlueText,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}
