package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.JarvisViewModel
import com.example.viewmodel.TerminalMessage
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TerminalScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val logs by viewModel.terminalLogs.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Auto scroll to bottom when new logs appear
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDark)
    ) {
        // Core Jarvis Visual Indicator (The Holographic AI Arc Reactor Core)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            JarvisNeuralCore(isGenerating = isGenerating)
        }

        // Output Display Terminal Box
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, CyberCyan.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(CyberSurface.copy(alpha = 0.4f))
        ) {
            // Retro Grid Overlay Scanner Lines
            Canvas(modifier = Modifier.fillMaxSize()) {
                val gridGap = 30f
                val strokeWidth = 1f
                val color = CyberCyan.copy(alpha = 0.03f)

                // Horizontal
                var y = 0f
                while (y < size.height) {
                    drawLine(color, Offset(0f, y), Offset(size.width, y), strokeWidth)
                    y += gridGap
                }
                // Vertical
                var x = 0f
                while (x < size.width) {
                    drawLine(color, Offset(x, 0f), Offset(x, size.height), strokeWidth)
                    x += gridGap
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(logs) { log ->
                    when (log) {
                        is TerminalMessage.Jarvis -> {
                            JarvisMessageRow(log)
                        }
                        is TerminalMessage.User -> {
                            UserMessageRow(log)
                        }
                    }
                }

                if (isGenerating) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Text(
                                "JARVIS is thinking",
                                color = CyberCyan,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            // Simple text typing dots animation
                            val transition = rememberInfiniteTransition(label = "dots")
                            val alpha1 by transition.animateFloat(
                                initialValue = 0.2f, targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(400, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ), label = "dot1"
                            )
                            val alpha2 by transition.animateFloat(
                                initialValue = 0.2f, targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(400, delayMillis = 150, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ), label = "dot2"
                            )
                            val alpha3 by transition.animateFloat(
                                initialValue = 0.2f, targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(400, delayMillis = 300, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ), label = "dot3"
                            )
                            Text(".", color = CyberCyan.copy(alpha = alpha1), fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                            Text(".", color = CyberCyan.copy(alpha = alpha2), fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                            Text(".", color = CyberCyan.copy(alpha = alpha3), fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Suggestions Quick Flow Shortcuts
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val suggestions = listOf("Status Check", "Sunrise Protocol", "Deep Focus")
            suggestions.forEach { suggestion ->
                Box(
                    modifier = Modifier
                        .border(
                            1.dp,
                            ElectricBlue.copy(alpha = 0.4f),
                            RoundedCornerShape(16.dp)
                        )
                        .background(CyberSurface.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                        .clickable {
                            if (!isGenerating) {
                                when (suggestion) {
                                    "Status Check" -> viewModel.submitTerminalCommand("Jarvis, scan system status and run standard diagnostics.")
                                    "Sunrise Protocol" -> viewModel.submitTerminalCommand("Jarvis, initialize Sunrise Protocol sequence.")
                                    "Deep Focus" -> viewModel.submitTerminalCommand("Jarvis, formulate deep focus block goal and target objectives.")
                                }
                            }
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = suggestion,
                        color = CyberCyan.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Command Input Field Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
                .navigationBarsPadding(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                    .clip(RoundedCornerShape(24.dp))
                    .testTag("terminal_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = CyberSurface,
                    unfocusedContainerColor = CyberSurface,
                    disabledContainerColor = CyberSurface,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = LiquidBlueText,
                    unfocusedTextColor = LiquidBlueText
                ),
                placeholder = {
                    Text(
                        "Transmit order, Sir...",
                        color = SilverShieldText.copy(alpha = 0.6f),
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                leadingIcon = {
                    Text(
                        "> ",
                        color = CyberCyan,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                },
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            FloatingActionButton(
                onClick = {
                    if (inputText.isNotBlank() && !isGenerating) {
                        viewModel.submitTerminalCommand(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .size(46.dp)
                    .testTag("submit_button"),
                containerColor = ElectricBlue,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send Command",
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun JarvisNeuralCore(isGenerating: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    
    // Core breathing pulsing radius
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isGenerating) 600 else 1800, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "pulseScale"
    )

    // Secondary pulsing alpha
    val innerPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isGenerating) 800 else 2400, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "innerPulse"
    )

    Box(
        modifier = Modifier
            .size(190.dp)
            .testTag("jarvis_neural_core"),
        contentAlignment = Alignment.Center
    ) {
        // 1. Absolute outer pulsing circle with thin lavender border
        Box(
            modifier = Modifier
                .size(180.dp * pulseScale)
                .border(2.dp, CyberCyan.copy(alpha = 0.2f), CircleShape)
        )

        // 2. Medium absolute circle with thicker translucent border
        Box(
            modifier = Modifier
                .size(145.dp)
                .border(4.dp, CyberCyan.copy(alpha = 0.35f * innerPulseAlpha), CircleShape)
        )

        // 3. Main center gradient orb with high-tech shadow
        Box(
            modifier = Modifier
                .size(110.dp)
                .background(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            ElectricBlue, // Deep Accent Purple
                            CyberCyan,     // Soft Highlight Lavender
                            ElectricBlue
                        )
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            // Elegant inner glowing core graphic
            Box(
                modifier = Modifier
                    .size(94.dp)
                    .background(CyberPanel, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                // Drawing dynamic technical lines / visual EQ using Canvas
                Canvas(modifier = Modifier.size(54.dp)) {
                    val width = size.width
                    val height = size.height
                    val midY = height / 2
                    val bars = 6
                    val barWidth = 4f
                    val gap = 8f
                    val totalWidth = (bars * barWidth) + ((bars - 1) * gap)
                    val startX = (width - totalWidth) / 2

                    for (i in 0 until bars) {
                        val x = startX + i * (barWidth + gap)
                        // Make bar heights dynamic
                        val factor = if (isGenerating) {
                            Math.sin((i * 1.5 + (pulseScale * 10)).toDouble()).toFloat()
                        } else {
                            Math.sin((i * 0.8 + 2.0).toDouble()).toFloat()
                        }
                        val barHeight = (height * 0.45f) + (factor.coerceAtLeast(-1f).coerceAtMost(1f) * height * 0.35f)
                        drawLine(
                            color = Color.White,
                            start = Offset(x, midY - barHeight / 2),
                            end = Offset(x, midY + barHeight / 2),
                            strokeWidth = barWidth
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun JarvisMessageRow(log: TerminalMessage.Jarvis) {
    val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Jarvis Active",
                    tint = CyberCyan,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "JARVIS // STARK_DRIVE_CORE",
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (log.isSimulated) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(CyberAmber.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .border(1.dp, CyberAmber.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            "STANDALONE",
                            color = CyberAmber,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Text(
                formatter.format(Date(log.timestamp)),
                color = SilverShieldText.copy(alpha = 0.5f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Text(
            text = log.text,
            color = LiquidBlueText,
            fontSize = 13.5.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 18.sp,
            modifier = Modifier.padding(start = 20.dp, top = 4.dp, end = 8.dp)
        )
    }
}

@Composable
fun UserMessageRow(log: TerminalMessage.User) {
    val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "▶ COMMAND_UPLINK",
                    color = ElectricBlue,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                formatter.format(Date(log.timestamp)),
                color = SilverShieldText.copy(alpha = 0.5f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Text(
            text = log.text,
            color = OffwhiteJet,
            fontSize = 13.5.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(start = 14.dp, top = 4.dp, end = 8.dp)
        )
    }
}
