package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = CyberCyan,
    secondary = ElectricBlue,
    tertiary = CyberAmber,
    background = ObsidianDark,
    surface = CyberSurface,
    surfaceVariant = CyberPanel,
    onPrimary = ObsidianDark,
    onSecondary = OffwhiteJet,
    onTertiary = ObsidianDark,
    onBackground = LiquidBlueText,
    onSurface = OffwhiteJet,
    onSurfaceVariant = LiquidBlueText
  )

private val LightColorScheme = DarkColorScheme // Jarvis is strictly Dark for executive cockpit experience

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force Dark Theme for cockpit holographic console
  dynamicColor: Boolean = false, // Disable dynamic colors to keep pure custom branding
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
