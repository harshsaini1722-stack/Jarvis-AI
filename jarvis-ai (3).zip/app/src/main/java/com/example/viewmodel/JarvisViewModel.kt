package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.WorkflowBlueprint
import com.example.data.model.WorkflowHistoryLog
import com.example.data.repository.WorkflowRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface TerminalMessage {
    data class User(val text: String, val timestamp: Long = System.currentTimeMillis()) : TerminalMessage
    data class Jarvis(val text: String, val isSimulated: Boolean = false, val timestamp: Long = System.currentTimeMillis()) : TerminalMessage
}

class JarvisViewModel(private val repository: WorkflowRepository) : ViewModel() {

    // Terminal/Chat states
    private val _terminalLogs = MutableStateFlow<List<TerminalMessage>>(
        listOf(
            TerminalMessage.Jarvis(
                "Good day, Sir. I am JARVIS, your local automation core. Core processes are online. Terminal uplink is waiting for your vocal or textual instructions."
            )
        )
    )
    val terminalLogs: StateFlow<List<TerminalMessage>> = _terminalLogs.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    // Active executing workflow states
    private val _activeExecution = MutableStateFlow<ExecutionState?>(null)
    val activeExecution: StateFlow<ExecutionState?> = _activeExecution.asStateFlow()

    // List of active blueprints and historical logs from Room database
    val workflows: StateFlow<List<WorkflowBlueprint>> = repository.allBlueprints
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val historyLogs: StateFlow<List<WorkflowHistoryLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Auto-seed default daily automation rules on startup if database is empty
        viewModelScope.launch {
            repository.allBlueprints.collect { list ->
                if (list.isEmpty()) {
                    seedDefaultWorkflows()
                }
            }
        }
    }

    private suspend fun seedDefaultWorkflows() {
        val defaults = listOf(
            WorkflowBlueprint(
                title = "🌅 Sunrise Protocol (Morning)",
                description = "Automates startup briefing, diagnostics, and runs key generative day insights.",
                triggerCondition = "Daily: 07:00 AM / Manual Assist",
                actionsJson = "Telemetry Diagnostic Scan,Generate Daily Briefing Prompt,Configure virtual espresso heater",
                isActive = true,
                iconName = "WbSunny",
                executionCount = 0
            ),
            WorkflowBlueprint(
                title = "💻 Deep Work Initiator",
                description = "Blocks noise, prepares a structured focus prompt, and initiates tracking log.",
                triggerCondition = "Trigger on Demand / Focus Session",
                actionsJson = "Configure Firewall matrix,Formulate Focus Goal,Activate ambient study synthesizer",
                isActive = true,
                iconName = "Computer",
                executionCount = 0
            ),
            WorkflowBlueprint(
                title = "🧠 Mind-Query Protocol (Reflective)",
                description = "Triggers evening learning review and analyzes energy/mood coordinates via Gemini.",
                triggerCondition = "Daily: 09:30 PM / Check-in",
                actionsJson = "Retrieve day log telemetry,Generate Self-Reflection brief,Store productivity score",
                isActive = true,
                iconName = "Psychology",
                executionCount = 0
            ),
            WorkflowBlueprint(
                title = "🏋️ Gym Prep Protocol (Active)",
                description = "Prepares dynamic exercise sequence, plans hydration timers, and verifies system prep.",
                triggerCondition = "Monday/Wednesday/Friday Shift",
                actionsJson = "Evaluate physical energy baseline,Formulate custom set targets,Queue playlist simulator",
                isActive = true,
                iconName = "Fitness",
                executionCount = 0
            )
        )
        defaults.forEach { repository.insertBlueprint(it) }
    }

    fun submitTerminalCommand(command: String) {
        if (command.isBlank()) return
        
        // Add to terminal list
        _terminalLogs.value = _terminalLogs.value + TerminalMessage.User(command)
        _isGenerating.value = true

        viewModelScope.launch {
            val response = repository.generateJarvisResponse(
                prompt = command,
                systemInstruction = "You are JARVIS, an elegant, ultra-customized Sci-Fi AI console assistant inspired by Ironman. You guide the user's daily life workflow automation. Speak in a confident, highly polite, classic butler style ('Sir', 'Captain'). Keep responses somewhat concise but incredibly stylish and atmospheric."
            )
            _terminalLogs.value = _terminalLogs.value + TerminalMessage.Jarvis(
                text = response,
                isSimulated = response.contains("fallback") || response.contains("secondary local simulation")
            )
            _isGenerating.value = false

            // Append command query to global diagnostic logs
            repository.insertLog(
                WorkflowHistoryLog(
                    workflowId = null,
                    workflowName = "Jarvis Terminal Interface",
                    logMessage = "Command executed: '$command'",
                    status = "INFO",
                    generatedResponse = response.take(150) + "..."
                )
            )
        }
    }

    fun executeWorkflow(blueprint: WorkflowBlueprint) {
        if (_activeExecution.value != null) {
            // Already executing another
            submitTerminalCommand("Jarvis, system conflict: Trigger request received while another subprocess is running.")
            return
        }

        viewModelScope.launch {
            val actions = blueprint.actionsJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            _activeExecution.value = ExecutionState(
                blueprintId = blueprint.id,
                title = blueprint.title,
                totalSteps = actions.size,
                currentStepIndex = 0,
                currentStepLabel = "Initializing protocol...",
                stepsCompleted = emptyList()
            )

            // Log inicio
            repository.insertLog(
                WorkflowHistoryLog(
                    workflowId = blueprint.id,
                    workflowName = blueprint.title,
                    logMessage = "Protocol initiated: '${blueprint.title}' execution has started.",
                    status = "INFO"
                )
            )

            delay(1000) // Aesthetic delay for terminal initialization

            for ((index, action) in actions.withIndex()) {
                _activeExecution.value = _activeExecution.value?.copy(
                    currentStepIndex = index + 1,
                    currentStepLabel = "Running: $action..."
                )

                // Perform specific background tasks according to action types
                val resultBrief = performAutomationAction(action, blueprint)
                delay(1200) // Telemetry diagnostic visual pause

                _activeExecution.value = _activeExecution.value?.let { state ->
                    state.copy(
                        stepsCompleted = state.stepsCompleted + StepCompletion(
                            label = action,
                            status = "COMPLETED",
                            outcomeSummary = resultBrief
                        )
                    )
                }

                // Log per step
                repository.insertLog(
                    WorkflowHistoryLog(
                        workflowId = blueprint.id,
                        workflowName = blueprint.title,
                        logMessage = "Step ${index + 1}/${actions.size} Completed: '$action'",
                        status = "SUCCESS",
                        generatedResponse = resultBrief
                    )
                )
            }

            // Finalized successfully
            repository.incrementExecutionStats(blueprint.id, System.currentTimeMillis())

            repository.insertLog(
                WorkflowHistoryLog(
                    workflowId = blueprint.id,
                    workflowName = blueprint.title,
                    logMessage = "Protocol successfully finalized: All micro-actions synchronized, Sir.",
                    status = "SUCCESS"
                )
            )

            _terminalLogs.value = _terminalLogs.value + TerminalMessage.Jarvis(
                text = "Sir, the '${blueprint.title}' has completed all manual and generative action steps. Telemetry is locked in database registers.",
                isSimulated = false
            )

            delay(2000)
            _activeExecution.value = null
        }
    }

    private suspend fun performAutomationAction(actionName: String, blueprint: WorkflowBlueprint): String {
        // If it requires AI content (contains 'Briefing', 'Self-Reflection', 'Focus Goal', 'exercise sequence')
        val lower = actionName.lowercase()
        val prompt = if (lower.contains("briefing")) {
            "Generate a highly refined morning briefing, Sir. Check weather coordinates briefly (mention virtual rain parameters/sunshine forecast), give a brief motivational focus mission for today, and sign off as JARVIS."
        } else if (lower.contains("focus goal") || lower.contains("self-reflection")) {
            "Formulate a custom reflection question based on tracking daily workflow. Give 2 tailored suggestions for higher energy reserves."
        } else if (lower.contains("exercise sequence")) {
            "Develop a quick but elegant customized fitness workflow suggestion. Focus on calibration and energy optimization status."
        } else {
            ""
        }

        if (prompt.isNotEmpty()) {
            return repository.generateJarvisResponse(
                prompt = prompt,
                systemInstruction = "You are JARVIS. Respond in 2-3 lines of highly custom, Sci-Fi butler styled executive notes."
            )
        }

        // Simulating offline micro-services
        return when {
            lower.contains("diagnostic") -> "Telemetry reads standard. Temperature: 34°C, local CPU load: 12%, state synchronized."
            lower.contains("espresso") -> "Simulating secondary heater activation... Temperature set to 94°C. Liquid volume calibration standard."
            lower.contains("firewall") -> "Virtual firewall buffers successfully secured. Port scanning shields at 100% efficiency, Sir."
            lower.contains("ambient") -> "Synthesizer active: Playing 'Virtual Binaural Rain @ 432Hz'. Simulated neural sync rate: 98%."
            lower.contains("telemetry") -> "Telemetry logs pulled successfully. Records show 100% network synchronization."
            lower.contains("workout") -> "Sequence queued: 3 sets of Virtual Calisthenics, 15 Recompositions. Ready for action."
            else -> "Action '$actionName' executed successfully. Memory allocated, telemetry registers standard."
        }
    }

    fun addNewWorkflow(title: String, description: String, trigger: String, actions: List<String>) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val blueprint = WorkflowBlueprint(
                title = title,
                description = description,
                triggerCondition = if (trigger.isBlank()) "Manual Trigger" else trigger,
                actionsJson = actions.filter { it.isNotBlank() }.joinToString(","),
                isActive = true,
                iconName = "PlaylistAdd"
            )
            repository.insertBlueprint(blueprint)

            repository.insertLog(
                WorkflowHistoryLog(
                    workflowId = null,
                    workflowName = "Jarvis Core Compiler",
                    logMessage = "New custom routine compiled: '$title'",
                    status = "SUCCESS"
                )
            )
        }
    }

    fun toggleWorkflowActive(blueprint: WorkflowBlueprint) {
        viewModelScope.launch {
            repository.updateBlueprint(blueprint.copy(isActive = !blueprint.isActive))
            repository.insertLog(
                WorkflowHistoryLog(
                    workflowId = blueprint.id,
                    workflowName = blueprint.title,
                    logMessage = "Routine toggled. Status is now: ${if (!blueprint.isActive) "ACTIVE" else "DEACTIVATED"}",
                    status = "INFO"
                )
            )
        }
    }

    fun deleteWorkflow(blueprint: WorkflowBlueprint) {
        viewModelScope.launch {
            repository.deleteBlueprint(blueprint)
            repository.insertLog(
                WorkflowHistoryLog(
                    workflowId = null,
                    workflowName = "Jarvis Core Decompiler",
                    logMessage = "Permanently deleted routine blueprint: '${blueprint.title}'",
                    status = "WARNING"
                )
            )
        }
    }

    fun clearAllLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }
}

data class ExecutionState(
    val blueprintId: Int,
    val title: String,
    val totalSteps: Int,
    val currentStepIndex: Int,
    val currentStepLabel: String,
    val stepsCompleted: List<StepCompletion>
)

data class StepCompletion(
    val label: String,
    val status: String,
    val outcomeSummary: String
)

class JarvisViewModelFactory(private val repository: WorkflowRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(JarvisViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return JarvisViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
